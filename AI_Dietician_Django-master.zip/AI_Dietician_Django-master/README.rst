AI_Dietician_Django


Example project
You can check out our example project by cloning the repo and heading into example/ directory.


Documented By- omkar jadhav

How to Run this Code?
Follow these steps:
        1. Clone this Project https://github.com/prabureddy/AI_Dietician_Django.git
        2. Open your terminal in AI_Dietician/ folder which contains requirements.txt file.
        3. Create virtual environment
                Steps to create Virtual Environment
            1. Run this command in your Terminal or CMD:- conda create --name AI_Dietician
                if any error while running this command install conda from here https://docs.conda.io/en/latest/miniconda.html
            2. It asks [y/n] :- press y on your keyboard
            3. After Creating Virtual Environment Activate it. To Activate run this command:- activate AI_Dietician
            4. Now Virtual Environment is activated in your terminal
        4. After Activating Virtual Environment Install required packages using this command:- pip install -r requirements.txt
        5. Now open your terminal in AI_Dietician/AI_Dietician which contains manage.py file.
        6. now run these following command to migrate database
            1. py manage.py migrate
            2. py manage.py makemigrations
            3. again run:- py manage.py migrate
        7. Now atlast create admin to your app using this command:- py manage.py createsuperuser
        8. It asks some details fill it.
        9. Now it's complete Run this app by starting the server using:-  py manage.py runserver

Now server started
Open http://127.0.0.1:8000/ in your browser to view the app.

To View Admin panel go to http://127.0.0.1:8000/admin/ 

In this project we used backend which stores the form.
Fill the form and hit submit. The data is stored in database.

